import React, { Component } from 'react';
import {
  BrowserRouter,
  Routes,
  Route,
  Router,
  Navigate,
  Outlet,
} from "react-router-dom";
import  Recognit  from "./components/Recognit";
import  LogIn  from "./components/LogIn";
import  SignUp  from './components/SignUp';
import  ChooseSinger  from './components/chooseSinger';
import  Manager  from './components/Manager';
import  Home  from './components/Home';
import  Order  from './components/Order';
import SingerEntrance from './components/singerEntrance';
import SingerOrder from './components/SingerOrder';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/Recognit" element={<Recognit />}></Route>
        <Route path="/Recognit/LogIn" element={<LogIn />}></Route>
        <Route path="/" element={<Navigate to="/Recognit" replace />}></Route>
        <Route path="/Recognit/SignUp" element={<SignUp />}></Route>
        <Route path="/Recogit/chooseSinger" element={<ChooseSinger />}></Route>
        <Route path="/Recognit/Manager" element={<Manager />}></Route>
        <Route path="/Recognit/Home" element={<Home />}></Route>
        <Route path="/Recognit/Order" element={<Order />}></Route>
        <Route path="/Recognit/Home/LogIn" element={<LogIn />}></Route>
        <Route path="/Recognit/singerEntrance" element={<SingerEntrance />}></Route>
        <Route path="/Recognit/SingerOrder" element={<SingerOrder />}></Route>
      </Routes>
    </BrowserRouter>
  );
}
export default App;


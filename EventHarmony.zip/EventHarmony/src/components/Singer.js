import React, { Component, useState, useEffect } from 'react';
import { Link, useNavigate } from "react-router-dom";

function Singer() {

    let navigate = useNavigate();
    const [singers1, setSingers] = useState([]);

    useEffect(() => {
        getSingers();
    }, []);

    const getSingers = async () => {
        try {
            let singers = await fetch('http://localhost:3000/sql_music/singers');
            let singersData = await singers.json();
            setSingers([...singersData]);
        } catch (error) {
            alert(error)
        }
    }

    return (
        <div>
            <h1>singer</h1>
            {singers1.map((singer) =>
                <h1 key={singer.singer_code} singer={singer}>{`singer.singer_code`}</h1>
            )}
        </div>
    );
}

export default Singer;
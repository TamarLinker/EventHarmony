import React, { Component, useState, useEffect } from 'react';
import { useNavigate, useLocation } from "react-router-dom";
import SingleOrder from './SingleOrder';
// import { useNavigate, useLocation } from "react-router-dom";
import './css/singerEntrance.css'
function SingerEntrance() {
    let navigate = useNavigate();
    let location = useLocation();

    const [allWaitingOrders, setAllWaitingOrders] = useState([]);
    const [busyHour, setAllBusyHour] = useState([]);
    //const [visibleButton, setVisibleButton] = useState(false);
    const [disWaitingOrders, setDisWaitingOrders] = useState("none");
    const [disBusyHour, setDisBusyHour] = useState("none");
    const [limitWaitingOrder, setLimitWaitingOrder] = useState(0);
    const [limitGetAllBusyHour, setLimitGetAllBusyHour] = useState(0);
    const [showButtonWaitingOrder, setShowButtonWaitingOrder] = useState(false);
    const [showButtonGetAllBusyHour, setShowButtonGetAllBusyHour] = useState(false);

    
    const waitingOrder = async () => {
        setLimitGetAllBusyHour(0);
        setDisWaitingOrders("block");
        setDisBusyHour("none");
        try {
            let response = await fetch(`http://localhost:3000/orders/waitingOrders/${location.state.singer_code}/${limitWaitingOrder}`)
            response = await response.json();
            setAllWaitingOrders(response.waitingOrders);
            const limitNew = limitWaitingOrder + 2;
            setLimitWaitingOrder(limitNew);
            setShowButtonWaitingOrder(true);
            setShowButtonGetAllBusyHour(false);
        } catch (error) {
            alert(error)
        }
    }

    const getAllBusyHour = async () => {
        setLimitWaitingOrder(0);
        setDisBusyHour("block");
        setDisWaitingOrders("none");
        try {
            let response = await fetch(`http://localhost:3000/orders/getBusyDates/${location.state.singer_code}/${limitGetAllBusyHour}`)
            response = await response.json();
            setAllBusyHour(response.busyDates);
        } catch (error) {
            alert(error);
        }
        const limitNew = limitGetAllBusyHour + 2;
        setLimitGetAllBusyHour(limitNew);
        setShowButtonGetAllBusyHour(true);
        setShowButtonWaitingOrder(false);
    }

    const insertBusyHour = async () => {
        navigate('/Recognit/SingerOrder', { state: { singer_code: location.state.singer_code } })
    }

    const handler = async (index) => {
        allWaitingOrders.splice(index, 1);
        setAllWaitingOrders([...allWaitingOrders])
    }

    let index = 0;
    return (
        <div id="cc">
            <h1 className='h1'>singerEntrance</h1>
            <div id="cos">
                <button className="cos2 btn btn-default btn-block btn-custom" onClick={waitingOrder}>הזמנות ממתינות</button>
                <button className="cos2 btn btn-default btn-block btn-custom" onClick={getAllBusyHour}>כל השעות התפוסות</button>
                <button className="cos2 btn btn-default btn-block btn-custom" onClick={insertBusyHour}>הכנסה של שעה תפוסה</button>
            </div>
            <div style={{ display: disWaitingOrders }} id="yell">
                {allWaitingOrders.map((waitingOrders) =>
                    <SingleOrder key={waitingOrders.busy_dates_details_code} value={waitingOrders} stateChanger={handler} index={index++} buttonShow={true} />
                )}
            </div>
            <div style={{ display: disBusyHour }} id="yell">
                {busyHour.map((busyHouri) =>
                    <SingleOrder key={busyHouri.busy_dates_details_code} value={busyHouri} buttonShow={false} />
                )}
            </div>
            <br></br>{showButtonWaitingOrder && <button className="cos2 min" onClick={waitingOrder}>next</button>}
            <br></br>{showButtonGetAllBusyHour && <button className="cos2 min" onClick={getAllBusyHour}>next</button>}
        </div>

    );
}

export default SingerEntrance;
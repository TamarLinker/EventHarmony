import React, { Component, useState, useEffect } from 'react';
import { Navigate, useNavigate } from "react-router-dom";


function SingleOrder(props) {
    const [buttonShowEve, setButtonShowEve] = useState(false);
    const [buttonShow, setButtonShow] = useState(false);
    const [mailOptions, setMailOptions] = useState({ from: '', to: '', subject: '', text: '' });

    useEffect(() => {
        getMail();
        if (!props.manager) {
            if (props.value.is_event == 1 && props.value.acceptedEvent == 0) {
                setButtonShowEve(true);
            }
            if (props.value.is_event == 0) {
                setButtonShow(true);
            }
        }
    }, []);

   
    const getMail = async () => {
        let responseEmail;
        try {
            const response = await fetch(`http://localhost:3000/singerEntrance/getEmail/${props.value.busy_dates_details_code}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            });
            responseEmail = await response.json();
            setMailOptions({ from: 'projecttamarshani@gmail.com', to: responseEmail[0].e_mail, subject: 'Your request has been processed', text: 'Your order has been successfully confirmed!' })
        } catch (error) {
            // alert(responseEmail);
            alert(error);
        }
    }

    //updating
    const approval1 = async () => {
        try {
            const response = await fetch(`http://localhost:3000/singerEntrance/wantToAccept/${props.value.busy_dates_details_code}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            });
            let changed = await response.json();
            if (changed.changedRows) {
                props.stateChanger(props.index);
                sendingAnEmail();
            }
        } catch (error) {
            alert(error)
        }

    }

    const rejection = async () => {
        let responseEmail;
        try {
            const response1 = await fetch(`http://localhost:3000/singerEntrance/getEmail/${props.value.busy_dates_details_code}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            });
            responseEmail = await response1.json();
            setMailOptions({ from: 'projecttamarshani@gmail.com', to: responseEmail[0].e_mail, subject: 'Your request has been processed', text: 'Your order has not been confirmed' })
        }
        catch (error) {
            alert(responseEmail[0])
        }
        try {
            let response = await fetch(`http://localhost:3000/singerEntrance/deleteOrder/${props.value.busy_dates_details_code}`, {
                method: 'DELETE',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            })
            let delateResponse = await response.json();
            if (delateResponse.response.affectedRows) {
                props.stateChanger(props.index);
            }
            sendingAnEmail({ from: 'projecttamarshani@gmail.com', to: responseEmail[0].e_mail, subject: 'Your request has been rejected', text: 'Your order has not been confirmed' });
        } catch (error) {
            alert(error);
        }
    }

    const sendingAnEmail = async (mailOptions) => {
        try {
            const response = await fetch('http://localhost:3000/mail/send', {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(mailOptions)
            });
            let responseEmail = await response.json();
            if (responseEmail) {
                alert(responseEmail);
            }
            else {
                alert("לא נשלחה הודעת הצטרפות ללקוח המבוקש!");
            }
        } catch (error) {
            alert(error);
        }
    }

    // const simpleInsert = async () => {
    //     console.log(props.value)
    //     debugger
    //     let bool = false;
    //     try {
    //         const response = await fetch('http://localhost:3000/orders/simpleInsert', {
    //             method: "POST",
    //             headers: {
    //                 'Accept': 'application/json',
    //                 'Content-Type': 'application/json'
    //             },
    //             body: JSON.stringify(props.value)
    //         });
    //         let responseEmail = await response.json();
    //     } catch (error) {
    //         alert(error)
    //         bool=true;
    //     }
    //     if (!bool) {
    //         alert("העיסוק נכניס בהצלחה למערכת!")
    //     }
    //};

    return (
        <div className='singer'>

            <p>תאריך תפוס: {props.value.busy_date}</p>
            <p>שעת התחלה: {props.value.beginning_time}</p>
            <p>שעת סיום: {props.value.end_time}</p>
            {/* <p>כתובת: {props.value.address}</p> */}
            {props.show && <p>כתובת: {props.value.address}</p>}
            <p> ארוע:{props.value.is_event == 1 ? " לא " : "כן"}</p>

            {buttonShowEve && <><button onClick={approval1}>אישור וקבלת הזמנה</button>
                <button onClick={rejection}>מחיקת הבקשה</button> </>}
            {buttonShow && <button onClick={rejection}>מחיקת את התאריך התפוס</button>}
            {/* {props.buttonSimpleInsert && <button onClick={simpleInsert}>קביעת העיסוק הנל</button>} */}
        </div>
    );
}

export default SingleOrder;

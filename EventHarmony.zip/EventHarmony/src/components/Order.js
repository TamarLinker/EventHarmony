import { useLocation, useNavigate } from "react-router-dom";
import React, { useState, useEffect, Component } from 'react';

function Order() {
    let location = new useLocation();
    let navigate = new useNavigate();

    const [orderDetails, setOrderDetails] = useState({
        costumer_code: location.state.user_code,
        singer_code: location.state.singer_code,
        endHour: location.state.allDateAndHourDetails.endHour,
        beginHour: location.state.allDateAndHourDetails.beginHour,
        date: location.state.allDateAndHourDetails.date,
        hallsAddress: ""
    });


    function insertAddress(e) {
        const value = e.target.value;
        setOrderDetails({
            ...orderDetails,
            hallsAddress: value
        });
    }

    const makeAnOrder = async () => {
        try {
            const response = await fetch('http://localhost:3000/orders/makeAnOrder', {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(orderDetails)
            });
            if (response.status == 200) {
                alert("בקשתך נשלחה בהצלחה");
                navigate('/Recogit/ChooseSinger', { state: { user_code: location.state.user_code } })
            }
            else
                alert("בקשתך נשלחה בהצלחה");
        } catch (error) {
            alert(error)
        }
    }

    return (
        <div>
            <h1>שלב אחרון!!</h1>
            <label>כתובת אולם:</label><br />
            <input placeholder="address" onBlur={insertAddress}></input><br />
            <input type="button" value="makeAnOrder" onClick={makeAnOrder}></input>
        </div>
    );
}

export default Order;
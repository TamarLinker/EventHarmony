import { Navigate, useNavigate } from "react-router-dom";
import React, { useState, useEffect, Component } from 'react';
import ChooseSinger from './chooseSinger';
import Order from './Order';
import { useLocation } from "react-router-dom";

function SelectTime(props) {

    let navigate = new useNavigate();

    const [musicTypes, setMusicTypes] = useState([]);
    const [music, setMusic] = useState('');
    const [selectDate, setSelectDate] = useState('');
    const [selectHourBegin, setSelectHourBegin] = useState('');
    const [selectHourEnd, setSelectHourEnd] = useState('');
    const [currentDate, setCurrentDate] = useState('');

    useEffect(() => {
        let date = new Date();
        let month = date.getMonth();
        let day = date.getDate();
        if ((date.getMonth() + 1) < 10) {
            month = "0" + (date.getMonth() + 1);
        }
        if (date.getDate() < 10) {
            day = "0" + date.getDate();
        }
        const today = `${date.getFullYear()}-${month}-${day}`;
        setCurrentDate(today);
        setSelectDate(today);
        getMusicTypes();
    }, [])

    //תאריך נבחר
    const selectDateFunc = (e) => {
        setSelectDate(e.target.value)
    }

    //שעה שנבחרה
    const selectHourBeginFunc = (e) => {
        setSelectHourBegin(e.target.value)
    }

    const selectHourEndFunc = (e) => {
        setSelectHourEnd(e.target.value)
    }

    const getMusicTypes = async () => {
        try {
            let musicTypes = await fetch(`http://localhost:3000/MusicTypes/all`);
            let musicTypesNew = await musicTypes.json();
            setMusicTypes([...musicTypesNew]);
        } catch (error) {
            alert(error);
        }
    }

    //סוג תזמורת
    const musicTypeFunc = (e) => {
        setMusic(e.target.value)

    }

    const sendBackDetails = () => {
        props.func(selectDate, selectHourEnd, selectHourBegin, music);
    }

    return (
        <div className='singer deta'>
            <h2>selecTimeAndDate</h2>
            <label htmlFor="date_costumer"> enter optional date </label>
            <input type="date" value={selectDate} min={currentDate} onChange={selectDateFunc}></input><br></br>
            <label>Enter the start time of the event</label>
            <input type="time" value={selectHourBegin} onChange={selectHourBeginFunc}></input><br></br>
            <label>Enter the duration of the event</label>
            <input type="time" value={selectHourEnd} onChange={selectHourEndFunc}></input><br></br>
            <h1>{props.showSelect}</h1>
            {props.showSelect &&
                <>
                    <select name="side" onChange={musicTypeFunc} >
                        <option>choose type of music</option>
                        {musicTypes.map((musicType) =>
                            <option value={musicType.music_types_code}>{musicType.musicTypeName}</option>)}
                    </select><br />
                </>}
            <button onClick={sendBackDetails}>אישור</button>
        </div>
    );
}

export default SelectTime;
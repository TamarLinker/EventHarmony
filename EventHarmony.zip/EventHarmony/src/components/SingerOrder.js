import { Navigate, useNavigate, useLocation } from "react-router-dom";
import React, { useState, useEffect, Component } from 'react';
import SelecTimeAndDate from './SelecTimeAndDate';
import SingleOrder from './SingleOrder';

function SingerOrder(props) {
    // useEffect(() => {
    //     debugger;
    // }, [])
    const location = useLocation();
    const [showOrders_Booked, setShowOrders_Booked] = useState(false);
    const [showOrders_NotBooked, setShowOrders_NotBooked] = useState(false);
    const [showH1, setShowH1] = useState(false);
    const [singleOrder, setSingleOrder] = useState('');
    const [buttonShow, setButtonShow] = useState(false);
    const [orderDetailsInsert, setOrderDetailsInsert] = useState({ busy_date: '', beginning_time: '', end_time: '', singer_code: location.state.singer_code });
    const [orderDetails, setOrderDetails] = useState([{ busy_date: '', beginning_time: '', end_time: '', singer_code: location.state.singer_code }]);
    //const [buttonSimpleInsert, setButtonSimpleInsert] = useState(false);
    let showAdress;

    const checkIfAcceptedOrder = (response) => {
        response.map((orderDetail) => {
            if (orderDetail.acceptedEvent == 1 && orderDetail.is_event == 1) { setShowH1(true); return true; debugger }
        });
        setShowOrders_Booked(true);
    }
    const handler = async (index) => {
        orderDetails.splice(index, 1);
        setOrderDetails([...orderDetails])
    }

    const insertBusyTimeSinger = async (get_date, get_beginHour, get_endHour) => {
        setOrderDetailsInsert(prev => {
            return { ...prev, busy_date: get_date, beginning_time: get_beginHour, end_time: get_endHour }
        })
        let response = await fetch('http://localhost:3000/orders/insertBusyTimeSinger', {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ busy_date: get_date, beginning_time: get_beginHour, end_time: get_endHour, singer_code: location.state.singer_code })
        });
        response = await response.json();
        setOrderDetails([...response])
        // if (response.length == 0)
        //     setButtonSimpleInsert(true)
        // else
            checkIfAcceptedOrder(response);

       // console.log(orderDetails)
    }
    return (
        <>   
            <SelecTimeAndDate func={insertBusyTimeSinger} showSelect={false} />
            {showH1 && <h1>you are booked already on this day</h1>}
            {showOrders_Booked && <>{orderDetails.map((orderDetail) =>
             <><p>{orderDetail.is_event == 1 ? showAdress=true :showAdress=false}</p>
                    <SingleOrder value={orderDetail} showAdress={showAdress} showH1={showH1} stateChanger={handler} checkIfAcceptedOrder={checkIfAcceptedOrder} valueInsert={orderDetailsInsert}/> </> 
            )}</>}
        </>
    );
}

export default SingerOrder;





    // const insertBusyTimeSinger1 = (fetchYesOrNot) => {
    //     debugger;
    //     insertBusyTimeSinger(orderDetails.busy_date, orderDetails.beginning_time, orderDetails.end_time, fetchYesOrNot)
    // }
    // const insertBusyTimeSinger = async (get_date, get_beginHour, get_endHour, fetchYesOrNot) => {
    //     setOrderDetails(prev => {
    //         return { ...prev, busy_date: get_date, beginning_time: get_beginHour, end_time: get_endHour, fetchYesOrNot: fetchYesOrNot }
    //         // busy_date: get_date,
    //         // beginning_time: get_beginHour,
    //         // end_time: get_endHour,
    //         // fetchYesOrNot: fetchYesOrNot
    //     })
    //     console.log(orderDetails)
    //     console.log(fetchYesOrNot)
    //     debugger;

    //     let response = await fetch('http://localhost:3000/orders/insertBusyTimeSinger', {
    //         method: "POST",
    //         headers: {
    //             'Accept': 'application/json',
    //             'Content-Type': 'application/json'
    //         },
    //         body: JSON.stringify({ busy_date: get_date, beginning_time: get_beginHour, end_time: get_endHour, singer_code: location.state.singer_code, fetchYesOrNot: fetchYesOrNot })
    //     });
    //     response = await response.json();
    //     if (response == "booked") {
    //         setShowH1(true)
    //     }
    //     setSingleOrder(response)
    //     if (response != "insert succeded") {
    //         debugger;
    //         if (response.is_event == 1) {
    //             if (response.acceptedEvent == 1) {
    //                 setShowH1(true)
    //             }
    //             else {
    //                 setShowSingleOrder(true)
    //             }
    //         }
    //         else {
    //             setShowSingleOrder1(true)
    //         }
    //     }
    //     else
    //         alert(response)
    //     console.log(response)

    // }

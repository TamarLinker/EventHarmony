import React, { useState, Component } from 'react';
import SingleSinger from './singleSinger';
import SingleOrder from './SingleOrder';



function Manager() {

    const [allSingers, setAllSingers] = useState([]);
    const [showButtonDeletion, setShowButtonDeletion] = useState(false);
    const [showButtonUpdating, setShowButtonUpdating] = useState(false);
    const [showButtonOrder, setShowButtonOrder] = useState(false);
    const [allAcceptedOrders, setAllAcceptedOrders] = useState([]);
    const [allNotAcceptedOrders, setAllNotAcceptedOrders] = useState([]);
    const [limitAccepted, setLimitAccepted] = useState(0);
    const [limitNotAccepted, setLimitNotAccepted] = useState(0);
    const [showButtonNotAccepted, setShowButtonNotAccepted] = useState(false);
    const [showButtonAccepted, setShowButtonAccepted] = useState(false);
    const [showSingleSinger, setShowSingleSinger] = useState(false);
    const [showSingleOrder, setShowSingleOrder] = useState(false);



    // המאופשרים להביא את כל הזמרים
    const getAcceptedSingers = async () => {
        try {
            setLimitNotAccepted(0);
            let singers = await fetch(`http://localhost:3000/manager/accepted/${limitAccepted}`);
            let singersData = await singers.json();
            setShowSingleSinger(true);
            setShowSingleOrder(false);
            setAllSingers(singersData);
            setShowButtonDeletion(true);
            setShowButtonUpdating(false);
            const limitNew = limitAccepted + 2;
            setLimitAccepted(limitNew);
            setShowButtonAccepted(true);
            setShowButtonNotAccepted(false);
        } catch (error) {
            alert(error);
        }
    }

    //להביא את כל הזמרים המבקשים 
    const getNotAcceptableSingers = async () => {
        try {
            setLimitAccepted(0);
            let singers = await fetch(`http://localhost:3000/manager/notAccepted/${limitNotAccepted}`);
            let singersData = await singers.json();
            setShowSingleSinger(true);
            setShowSingleOrder(false);
            setAllSingers(singersData);
            setShowButtonDeletion(true);
            setShowButtonUpdating(true);
            const limitNew = limitNotAccepted + 2;
            setLimitNotAccepted(limitNew);
            setShowButtonNotAccepted(true);
            setShowButtonAccepted(false);
        } catch (error) {
            alert(error);
        }
    }

    const getAcceptedOrders = async () => {
        try {
            let orders = await fetch(`http://localhost:3000/orders/accepted`);
            let ordersData = await orders.json();
            setShowSingleSinger(false);
            setShowSingleOrder(true);
            setAllNotAcceptedOrders([...ordersData.acceptedOrders]);
        } catch (error) {
            alert(error);
        }
    }

    const getNotAcceptedOrders = async () => {
        try {
            let ordersNot = await fetch(`http://localhost:3000/orders/notAccepted`);
            let ordersData = await ordersNot.json();
            setShowSingleSinger(false);
            setShowSingleOrder(true);
            setAllNotAcceptedOrders([...ordersData.notAcceptedOrders]);
        } catch (error) {
            alert(error);
        }
    }

    const handler = async (index) => {
        allSingers.splice(index, 1);
        setAllSingers([...allSingers])
    }

    let index = 0;
    return (
        <div  dir='rtl'>
            <h1 className='h1'>מנהל</h1>
            <button className='cos2' onClick={getNotAcceptableSingers}>אישור וקבלת זמרים</button>
            <button className='cos2' onClick={getAcceptedSingers}>זמרים קיימים</button>
            <button className='cos2' onClick={getAcceptedOrders}>הזמנות מאושרות</button>
            <button className='cos2' onClick={getNotAcceptedOrders}>הזמנות לא מאושרות</button>
            {/* {allSingers.map((singer) =>
                <SingleSinger key={singer.singer_code} value={singer} showDeletion={showButtonDeletion}
                    showUpdating={showButtonUpdating} showOrder={showButtonOrder} stateChanger={handler} index={index++} />
            )} */}


            {showSingleSinger && <div className='grid'> {allSingers.map((singer) =>
                <SingleSinger key={singer.singer_code} value={singer} showDeletion={showButtonDeletion}
                    showUpdating={showButtonUpdating} showOrder={showButtonOrder} stateChanger={handler} index={index++} />
            )} </div>}
            {showSingleOrder && <div className='grid'>{allNotAcceptedOrders.map((notAcceptedOrder) =>
                <SingleOrder value={notAcceptedOrder} show={true} buttonShow={false} />
            )} </div>}


            {showButtonNotAccepted && <button className='cos2' onClick={getNotAcceptableSingers}>next</button>}
           {showButtonAccepted && <button  className='cos2 min' onClick={getAcceptedSingers}>next</button>}
            {/* {allAcceptedOrders.map((acceptedOrder) =>
            //לקחת מסינגל אורדר
            )} */}
            {/* {allNotAcceptedOrders.map((notAcceptedOrder) =>
            //לקחת מסינגל אורדר
            )} */}
        </div>
    )
}
export default Manager;
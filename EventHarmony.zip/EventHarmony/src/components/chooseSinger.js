import React, { useState, useEffect } from 'react';
import SingleSinger from './singleSinger';
import { useNavigate, useLocation } from "react-router-dom";
import SelecTimeAndDate from './SelecTimeAndDate';
import Order from './Order';

function ChooseSinger() {
    let location = new useLocation();
    let navigate = useNavigate();
    // const [musicTypes, setMusicTypes] = useState([]);
    const [music, setMusic] = useState('');
    const [allAvailbeSingers, setAllAvailbeSingers] = useState([]);
    const [showButtonDeletion, setShowButtonDeletion] = useState(false);
    const [showButtonUpdating, setShowButtonUpdating] = useState(false);
    const [showButtonOrder, setShowButtonOrder] = useState(true);
    const [showChildComponent, setShowChildComponent] = useState(true);
    const [allDateAndHourDetails1, setAllDateAndHourDetails] = useState({ date: "", beginHour: "", endHour: "" });
    const [showH1, setShowH1] = useState('');

    //מביא את כל הזמרים הפנוים
    const selectAvailableSingers = async (get_date, get_beginHour, get_endHour, get_music) => {
        try {
            let response = await fetch('http://localhost:3000/ChooseSinger/availableSingers', {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ busy_date: get_date, beginning_time: get_beginHour, end_time: get_endHour, music_types_code: get_music })
        });
        response = await response.json();
        setAllAvailbeSingers(response);
        checkIfFound(response);
        } catch (error) {
            alert(error);
        }      
    }

    const setAllState = (get_date, get_beginHour, get_endHour, get_music) => {
        setAllDateAndHourDetails({
            date: get_date,
            beginHour: get_beginHour,
            endHour: get_endHour
        });
        setMusic(get_music);
    }

    const checkIfFound = (availbeSingers) => {
        if (availbeSingers[0] == undefined)
            setShowH1(true)
        else
            setShowH1(false)
    }

    const getDetailsFromChild = (get_date, get_beginHour, get_endHour, get_music) => {
        setShowChildComponent(false);
        setAllState(get_date, get_beginHour, get_endHour, get_music);
        selectAvailableSingers(get_date, get_beginHour, get_endHour, get_music);
    }

    const BackHomePage = () => {
        navigate('/Recognit/Home');
    }
    return (
        <div>
          
            {!showH1 && <h1 className='h1'>choose singer</h1>}
            <button className='cos2' onClick={BackHomePage}>Back to the home page</button>
            <SelecTimeAndDate func={getDetailsFromChild} showSelect={true} />
            {allAvailbeSingers.map((singer) =>
                <SingleSinger key={singer.singer_code} value={singer} showDeletion={showButtonDeletion}
                    showUpdating={showButtonUpdating} showOrder={showButtonOrder} user_code={location.state.user_code} allDateAndHourDetails={allDateAndHourDetails1} />
            )}
            {showH1 && <h6>no maching singerss are selected</h6>}
        </div>
    );
}

export default ChooseSinger;
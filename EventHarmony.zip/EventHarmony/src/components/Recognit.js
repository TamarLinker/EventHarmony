import { Navigate, useNavigate } from "react-router-dom";
import React, { useState, useEffect, Component } from 'react';
import './css/recognit.css'
function Recognit() {
    let navigate = new useNavigate();

    const checkStatus = (text) => {


        if (text === "singer") {
            navigate('LogIn', { state: { type: "singer" } });
        }
        else if (text === "manager") {
            navigate('LogIn', { state: { type: "manager" } });
        }
        else
            navigate('Home');
    }

    return (
        <div>
            <h1>הכנס סטטוס:</h1>
            <div id="select">
                <select name="side" onChange={(e) => { checkStatus(e.target.value) }}>
                    <option type="text" >choose status</option>
                    <option type="text" >singer</option>
                    <option type="text" >manager</option>
                    <option type="text" >costumer</option>
                </select><br />
            </div>
        </div>
    )
}
export default Recognit;
import React, { Component } from 'react';
import { Navigate, useNavigate } from "react-router-dom";

function Home() {
    let navigate = new useNavigate();

    const placeAnOrder = () => {
        navigate('LogIn', { state: { type: "is_costumer" } });
    }

    return (
        <div>
            <h1 className='h1'>home</h1>
            <button className='cos2' onClick={placeAnOrder}>לביצוע הזמנה</button>
            <h1 className='h1'></h1>
            <h2>      The music department of the National Library collects, documents, preserves and offers to the public any material related to Israeli and Jewish music.

            The collection is divided into three main areas: Land of Israel music (that which was written in the Land of Israel or by Israelis); Muslim-Christian music; and music of other groups that live in Israel.

            Collected materials: patterns (books and sheet music), archival materials (drafts of works, research lists, letters, photos, certificates, ads, programs, newspaper clippings, private recordings, etc.), audio and video recordings (records, CDs, tapes, etc.).

           In the archive of the department are rare and of national and international importance. Beside them, the collection also includes commercial publications, they are in print and in sound.       </h2>   </div>
    );
}

export default Home;
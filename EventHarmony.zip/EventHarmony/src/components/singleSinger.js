import React, { Component, useState, useEffect } from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
//import React, { useState, useEffect } from 'react';


function SingleSinger(props) {
    let navigate = useNavigate();
    const [mailOptions, setMailOptions] = useState({ from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'You have been accepted to the site', text: 'Successfully added to the singer database!' });

    useEffect(() => {
        //setMailOptions({ from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'You have been accepted to the site', text: 'Successfully added to the singer database!' })
    }, []);

    //delate
    const deletingSinger = async () => {
        try {
            setMailOptions(prev => {
                return { ...prev, from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'A response to your inquiry', text: 'Your request has not been accepted!' }
            })

            // setMailOptions({ from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'A response to your inquiry', text: 'Your request has not been accepted!' })
            let response = await fetch(`http://localhost:3000/manager/deleteSinger`, {
                method: 'DELETE',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ singer_code: props.value.singer_code, password: props.value.password })
            })
            let delateResponse = await response.json();
            if (delateResponse) {
                props.stateChanger(props.index);
                sendingAnEmail({ from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'A response to your inquiry', text: 'Your request has not been accepted!' });
            }
            else {
                alert("singer is alredy booked, can not be deleted")
            }
        } catch (error) {
            alert(error);
        }

    }

    //updating
    const approval = async () => {
        try {
            setMailOptions({ from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'You have been accepted to the site', text: 'Successfully added to the singer database!' })

            const response = await fetch(`http://localhost:3000/ChooseSinger/wantToAccept/${props.value.e_mail}`, {
                method: 'PUT',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
            });
            let changed = await response.json();
            if (changed.changedRows) {
                props.stateChanger(props.index);
                sendingAnEmail({ from: 'projecttamarshani@gmail.com', to: props.value.e_mail, subject: 'You have been accepted to the site', text: 'Successfully added to the singer database!' });
            }
        } catch (error) {
            alert(error);
        }
    }

    const sendingAnEmail = async (mailOptions) => {
        try {
            const response = await fetch('http://localhost:3000/mail/send', {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(mailOptions)
            });
            let responseEmail = await response.json();
            if (responseEmail) {
                alert(responseEmail);
            }
            else {
                alert("לא נשלחה הודעת הצטרפות לזמר המבוקש!");
            }
        } catch (error) {
            alert(error);
        }
    }

    //מעבר לדף הזמנה
    const makeAnOrder = () => {
        navigate('/Recognit/Order', { state: { singer_code: props.value.singer_code, user_code: props.user_code, allDateAndHourDetails: props.allDateAndHourDetails } })
    }

    return (
        <div className='singer'>
            <p>שם: {props.value.first_name}</p>
            <p>משפחה: {props.value.last_name}</p>
            <p>טלפון: {props.value.phone_number}</p>
            <p>מחיר: {props.value.price}</p>
            {props.showDeletion && <button onClick={deletingSinger}>הסרת זמר</button>}
            {props.showUpdating && <button onClick={approval}>אישור וקבלה</button>}
            {props.showOrder && <button onClick={makeAnOrder}>ביצוע הזמנה</button>}
        </div>
    )
}

export default SingleSinger;
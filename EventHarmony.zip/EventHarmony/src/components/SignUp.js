import React, { useState, useEffect } from 'react';
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom';

function SignUp() {
    let navigate = useNavigate();
    let location = useLocation();

    const [user, setUser] = useState({ firstName: "", lastName: "", phone_number: "", price: "", password: "", e_mail: "", entranceType: location.state.type });
    const [showPriceButton, setShowPriceButton] = useState(false);

    useEffect(() => {
        if (location.state.type == "singer")
            setShowPriceButton(true)
    }, []);
    function insertFirstName(e) {
        const value = e.target.value;
        setUser({
            ...user,
            firstName: value
        });
    }

    function insertLastName(e) {
        const value = e.target.value;
        setUser({
            ...user,
            lastName: value
        });
    }

    function insertPhone_number(e) {
        const value = e.target.value;
        setUser({
            ...user,
            phone_number: value
        });
    }

    function insertPrice(e) {
        const value = e.target.value;
        setUser({
            ...user,
            price: value
        });
    }

    function insertPassword(e) {
        const value = e.target.value;
        setUser({
            ...user,
            password: value
        });
    }

    function insertEmail(e) {
        const value = e.target.value;
        setUser({
            ...user,
            e_mail: value
        });
    }


    function checkDetails() {
        //validateEmail(user.e_mail);
        if (user.e_mail !== "" && user.firstName !== "" && user.lastName !== "" && user.phone_number !== "" && user.password !== "") {
            if (location.state.type == "singer") {
                if (user.price !== "" && checkPhone(user.phone_number))
                    signUp();
                else
                    alert("פרטי משתמש שגוים")
            }
            else
                signUp();
        }
        else {
            alert("פרטי משתמש שגוים")
        }
    }

    function validateEmail(e_mail) {
        let check = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
        return check.test(e_mail);
    }

    function checkPhone(phone) {
        if (phone.charAt(0) != '0') {
            return false;
        }
        else if (phone < 20000000 || phone > 999999999) {
            return false;
        }
        else
            return true;
    }


    //כאשר מכניס מישהו חדש בודק תקינות סיסמא והאם הוא קיים כבר
    const signUp = async () => {
        try {
            let response = await fetch('http://localhost:3000/signUp/all', {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(user)
            });
            response = await response.json();
            if (response === "please logIn, you exist in are web") {
                alert(response)
            }
            else if (user.entranceType == "singer") {
                alert("ברוכים הבאים זמר")
                navigate('/Recognit/singerEntrance')
            }
            else {
                alert("ברוכים הבאים לקוח")
                navigate('/Recogit/chooseSinger', { state: { user_code: response[0].costumer_code } })
            }
        } catch (error) {
            alert(error);
        }
    }

    return (
        <div>
            <div class="container">
                <div id="login-box">
                    <div class="logo">
                        <h1 class="logo-caption"><span class="tweak">S</span>ignUp</h1>
                    </div>
                    <div class="controls">
                        <input onBlur={insertFirstName} placeholder="שם פרטי" type="text" name="username" class="form-control" />
                        <br></br>
                        <input onBlur={insertLastName} placeholder="שם משפחה" type="text" name="username" class="form-control" />
                        <br></br>
                        <input onBlur={insertPhone_number} placeholder="טלפון" type="text" name="username" class="form-control" />
                        <br></br>
                        {showPriceButton && <input onBlur={insertPrice} type="text" name="username" placeholder="מחיר" class="form-control" />}
                        <br></br>
                        <input onBlur={insertEmail} placeholder="אימייל" type="text" name="username" class="form-control" />
                        <br></br>
                        <input onBlur={insertPassword} placeholder="סיסמא" type="text" name="username" class="form-control" />
                        <br></br>
                        <button type="button" value="sign up" onClick={checkDetails} class="btn btn-default btn-block btn-custom" >signUp</button>
                    </div>
                </div>
            </div>
            <div id="particles-js"></div>
        </div>
    );
}
export default SignUp;
import React, { useState, useEffect } from 'react';
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom';
import './css/login.css';

function LoginSignUp() {
    let navigate = useNavigate();
    let location = useLocation();

    const [user, setUser] = useState({ e_mail: "", password: "", entranceType: location.state.type });
    const [notManager, setNotManager] = useState(true);

    useEffect(() => {
        if (location.state.type == "manager")
            setNotManager(false)
    }, []);

    function insertPassword(e) {
        const value = e.target.value;
        setUser({
            ...user,
            password: value
        });
    }

    function insertEmail(e) {
        const value = e.target.value;
        setUser({
            ...user,
            e_mail: value
        });
    }

    function checkDetails() {
        if (user.e_mail != "" && user.password != "") {
            logIn();
        }
        else {
            alert("פרטי משתמש שגוים")
        }
    }

    const logIn = async () => {
        try {
            let response = await fetch('http://localhost:3000/logIn/all', {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(user)
            });
            response = await response.json();
            if (response.currentUser[0] == null) {
                alert("נא הירשם")
                navigate('/Recognit/SignUp', { state: { type: location.state.type } })
            }
            else if (user.entranceType == "manager") {
                alert("מנהל שלום")
                navigate('/Recognit/Manager')
            }
            else if (user.entranceType == "singer") {
                alert("ברוכים הבאים זמר")
                navigate('/Recognit/SingerEntrance', { state: { singer_code: response.currentUser[0].singer_code } })
            }
            else {
                alert("ברוכים הבאים לקוח")
                navigate('/Recogit/chooseSinger', { state: { user_code: response.currentUser[0].costumer_code } })
            }
        } catch (error) {
            alert(error)
        }
    }

    function signUp() {
        navigate('/Recognit/SignUp', { state: { type: location.state.type } })
    }

    return (
        <div>
            <div class="container">
                <div id="login-box">
                    <div class="logo">
                        <h1 class="logo-caption"><span class="tweak">L</span>ogin</h1>
                    </div>
                    <div class="controls">
                        <input onBlur={insertEmail} placeholder="אימייל" type="text" name="username" class="form-control" />
                        <br></br>
                        <input onBlur={insertPassword} placeholder="סיסמא" type="text" name="username" class="form-control" />
                        <br></br>
                        <button type="button" class="btn btn-default btn-block btn-custom" onClick={checkDetails}>Login</button>
                        {notManager && <button type="button" value="sign up" onClick={signUp} class="btn btn-default btn-block btn-custom" >signUp</button>}
                    </div>
                </div>
            </div>
            <div id="particles-js"></div>
        </div>
    );
}
export default LoginSignUp;
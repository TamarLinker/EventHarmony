const express= require('express');
const cors= require('cors');
const singers= require('./routes/singers')
const logIn= require('./routes/logIn')
const signUp= require('./routes/signUp');
const orders= require('./routes/orders');
const mail = require('./routes/mail');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use('/ChooseSinger', singers);
app.use('/logIn', logIn);
app.use('/signUp', signUp);
app.use('/manager', singers);
app.use('/MusicTypes', singers);
app.use('/orders', orders);
app.use('/singerEntrance', orders);
app.use('/mail',mail);


app.listen(port, () => {
    console.log('server is up and running')
});











// db.connect(function (err) {
//     if (err) console.log(err);
//     else console.log("connected");
// });                                                                                              

// app.get('/singers/:bookedSingers', (req, res) => {debugger;
//     console.log(req.params);
//     const bookedSingers1=req.params.bookedSingers;
//     data.query(`SELECT singers.first_name,
// singers.last_name from singers
// JOIN busy_dates on singers.singer_code=busy_dates.singer_code
// WHERE busy_dates.busy_date = ${bookedSingers1}`, function (err, effect) {
//         if (err)
//             console.log(err);
//         console.log(effect);
//         res.json(effect);
//     });
// });

    // data.query(sqlQuery, (err, result, fields) => {
    //     if (err) throw err;
    //     console.log(result);
    //     res.json(result);
    // });

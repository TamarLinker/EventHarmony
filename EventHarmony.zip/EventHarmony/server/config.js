const config = {
    db: {
      host: "localhost",
      user: "root",
      password: "1234.com",
      database: "orchestra_4_events",
    },
    listPerPage: 10,
  };
  module.exports = config;
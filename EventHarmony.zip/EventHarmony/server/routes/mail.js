const express = require('express');
const router = express.Router();
const  mail= require('../services/mail');


router.post('/send', async function (req, res, next) {
  try {
    res.json(await mail.sendEmail(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

module.exports = router;



const express = require('express');
const router = express.Router();
const signUp = require('../services/signUp');

router.post('/all', async function(req, res, next) {
  try {
    res.json(await signUp.signUp(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages`, err.message);
    next(err);
  }
});

module.exports = router;
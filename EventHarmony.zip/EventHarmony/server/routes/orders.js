const express = require('express');
const router = express.Router();
const orders = require('../services/orders');
///singerEntrance/getEmail/${props.value.busy_dates_details_code}`, {
  router.get('/accepted', async function (req, res, next) {
    try {
      res.json(await orders.getAcceptedOrders());
    } catch (err) {
      console.error(`Error while getting programming npmlanguages`, err.message);
      next(err);
    }
  });

router.post('/makeAnOrder', async function (req, res, next) {
  try {
    res.json(await orders.makeAnOrder(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages`, err.message);
    next(err);
  }
});

router.get('/notAccepted', async function (req, res, next) {
  try {
    res.json(await orders.getNotAcceptedOrders());
  } catch (err) {
    console.error(`Error while getting programming languages`, err.message);
    next(err);
  }
});


router.get('/waitingOrders/:singer_code/:limit', async function (req, res, next) {
  try {
    res.json(await orders.waitingOrders(req.params.singer_code,req.params.limit));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.post('/wantToAccept/:busy_dates_details_code', async function (req, res, next) {
  try {
    console.log(req.params.busy_dates_details_code)
    res.json(await orders.want2accept(req.params.busy_dates_details_code));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.post('/getEmail/:busy_dates_details_code', async function (req, res, next) {
  try {
    console.log(req.params.busy_dates_details_code)
    res.json(await orders.getEmail(req.params.busy_dates_details_code));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.post('/insertBusyTimeSinger', async function (req, res, next) {
  try {
  // console.log(req.body)
    res.json(await orders.insertBusyTimeSinger(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.delete('/deleteOrder/:busy_dates_details_code', async function (req, res, next) {
  try {
    res.json(await orders.deleteOrder(req.params.busy_dates_details_code));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.get('/getBusyDates/:singer_code/:limitGetAllBusyHour', async function (req, res, next) {
  try {
    res.json(await orders.getBusyDates(req.params.singer_code,req.params.limitGetAllBusyHour));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.delete('/deleteAndInsert', async function(req, res, next) {
  try {
     res.json(await orders.deleteAndInsert(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages`, err.message);
    next(err);
  }
});

module.exports = router;
const express = require('express');
const router = express.Router();
const singers = require('../services/singers');

router.get('/accepted/:limit', async function(req, res, next) {
  try {
    res.json(await singers.getAcceptedSingers(req.params.limit));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.post('/availableSingers', async function(req, res, next) {
  try {
    res.json(await singers.availableSingers(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.get('/all', async function(req, res, next) {
  try {
    res.json(await singers.getMusicTypes());
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.put('/wantToAccept/:e_mail', async function(req, res, next) {
  try {
    res.json(await singers.want2accept(req.params.e_mail));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.get('/notAccepted/:limit', async function(req, res, next) {
  try {
    res.json(await singers.getNotAcceptedSingers(req.params.limit));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.get('/:date', async function(req, res, next) {
  try {
    res.json(await singers.getSingersPorDate(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});

router.delete('/deleteSinger', async function(req, res, next) {
  try {
    console.log(req.body)
     res.json(await singers.deleteSinger(req.body));
  } catch (err) {
    console.error(`Error while getting programming languages`, err.message);
    next(err);
  }
});


module.exports = router;
const db = require('./db');
const config = require('../config');
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'projecttamarshani@gmail.com',
        pass: 'ewklxivfdmliiygy'
    }
});

async function sendEmail(mailOptions) {
    const res=await transporter.sendMail(mailOptions);
    if (res.response) {
        return ('Email sent: ' + res.accepted[0]);
    } else {
        return (res.response);
    }
    //  transporter.sendMail(mailOptions, function (error, info) {
    //     if (error) {
    //         console.log(mailOptions)
    //         return(error);
    //     } else {    

    //         return('Email sent: ' + info.response);
    //     }
    // });
}

module.exports = { sendEmail };
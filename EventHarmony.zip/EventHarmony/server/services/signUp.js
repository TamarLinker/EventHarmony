const db = require('./db');
const config = require('../config');

async function signUp(user) {
    console.log(user)

    if (user.entranceType == "singer") {
        const result = await db.query(`SELECT * FROM singers WHERE e_mail="${user.e_mail}"`);
        if (result[0] != null) {
            const exist = "please logIn, you exist in are web";
            return (exist);
        }
        else {
            const insertResult = await db.query(`INSERT INTO singers(first_name, last_name, phone_number, price, password,e_mail) VALUES ("${user.firstName}", "${user.lastName}", ${user.phone_number},${user.price}, ${user.password},"${user.e_mail}")`);
                       console.log("in if")
                       console.log(insertResult)

            if (insertResult) {
                return (insertResult);
            }
            else {
                return (false);
            }
        }
    }
    else {
        result = await db.query(`SELECT * FROM costumers WHERE e_mail="${user.e_mail}"`);
        if (result[0] != null) {
            const exist = "please logIn, you exist in are web";
            return (exist);
        }
        else {
            await db.query(`INSERT INTO costumers(first_name, last_name, phone_number, password,e_mail) VALUES ("${user.firstName}", "${user.lastName}", ${user.phone_number}, "${user.password}","${user.e_mail}");`);
            const insertResult =await db.query(`SELECT * FROM costumers WHERE e_mail="${user.e_mail}"`);
            if (insertResult) {

                return (insertResult);
            }
            else {
                return (false);
            }
        }
    }
}
module.exports = {
    signUp
}
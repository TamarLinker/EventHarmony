const db = require('./db');
const config = require('../config');

async function postCertainUser(user) {
  if (user.entranceType == "singer" || user.entranceType == "manager") {
    const currentUser = await db.query(`SELECT * FROM singers WHERE e_mail="${user.e_mail}" AND password="${user.password}"`);
    return {
      currentUser
    }
  }
  else {
    const currentUser = await db.query(`SELECT * FROM costumers WHERE e_mail="${user.e_mail}" AND password="${user.password}"`);
    return {
      currentUser
    }
  }
}
module.exports = {
  postCertainUser
}
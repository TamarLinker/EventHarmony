const db = require('./db');
const config = require('../config');

async function makeAnOrder(orderDetails) {
    const makeAnOrder = await db.query(`INSERT INTO busy_dates_details(singer_code, busy_date, costumer_code, is_event,beginning_time,end_time,address) VALUES
   (${orderDetails.singer_code}, "${orderDetails.date}", ${orderDetails.costumer_code},true, "${orderDetails.beginHour}", "${orderDetails.endHour}","${orderDetails.hallsAddress}");`);
    return {
        makeAnOrder
    }
}

async function getAcceptedOrders() {
    const acceptedOrders = await db.query('SELECT * FROM busy_dates_details WHERE acceptedEvent=1');
    return {
        acceptedOrders
    }
}

async function getNotAcceptedOrders() {
    const notAcceptedOrders = await db.query('SELECT * FROM busy_dates_details WHERE acceptedEvent=0');
    return {
        notAcceptedOrders
    }
}

async function waitingOrders(singer_code,limitWaitingOrder) {
    const waitingOrders = await db.query(`select * from busy_dates_details where singer_code=${singer_code} and acceptedEvent=0 limit 2 offset ${limitWaitingOrder}`);
    return {
        waitingOrders
    }
}

async function want2accept(busy_dates_details_code) {
    const changed = await db.query(`update busy_dates_details set acceptedEvent=1 where busy_dates_details_code=${busy_dates_details_code}`);
   console.log(changed)
    return (changed);
}

async function insertBusyTimeSinger(insertBusyTimeSingerNew) {
    const response = await db.query(`select * from busy_dates_details where
    (singer_code=${insertBusyTimeSingerNew.singer_code} and busy_date="${insertBusyTimeSingerNew.busy_date}" and 
    (
    (beginning_time>="${insertBusyTimeSingerNew.beginning_time}" and beginning_time<="${insertBusyTimeSingerNew.end_time}") 
    or
     (end_time<="${insertBusyTimeSingerNew.end_time}" and end_time>="${insertBusyTimeSingerNew.beginning_time}")
     or
     (end_time>="${insertBusyTimeSingerNew.end_time}" and beginning_time<="${insertBusyTimeSingerNew.beginning_time}") ));`);
     return (response);
}

async function deleteAndInsert(deleteAndInsertBusyDates) {
    await db.query(`DELETE FROM busy_dates_details WHERE busy_dates_details_code=${deleteAndInsertBusyDates.delete.busy_dates_details_code}`);
    const InsertABusyDate = await db.query(`INSERT INTO busy_dates_details
    (singer_code, busy_date, is_event,beginning_time,end_time,acceptedEvent) VALUES
    (${deleteAndInsertBusyDates.InsertABusyDate.singer_code}, "${deleteAndInsertBusyDates.InsertABusyDate.busy_date}", false,"${deleteAndInsertBusyDates.InsertABusyDate.beginning_time}", "${deleteAndInsertBusyDates.InsertABusyDate.end_time}",true);`)
   console.log(`INSERT INTO busy_dates_details
   (singer_code, busy_date, is_event,beginning_time,end_time,acceptedEvent) VALUES
   (${deleteAndInsertBusyDates.InsertABusyDate.singer_code}, "${deleteAndInsertBusyDates.InsertABusyDate.busy_date}", false,"${deleteAndInsertBusyDates.InsertABusyDate.beginning_time}", "${deleteAndInsertBusyDates.InsertABusyDate.end_time}",true);`)
    console.log(InsertABusyDate)
    return (InsertABusyDate);
}

async function getEmail(busy_dates_details_code) {
    const response = await db.query(`select e_mail from costumers where costumer_code=(select costumer_code from busy_dates_details where busy_dates_details_code=${busy_dates_details_code})`)
    console.log(response)
    return (response);
}

async function getBusyDates(singer_code,limitGetAllBusyHour) {
    const busyDates = await db.query(`select * from busy_dates_details where singer_code=${singer_code} and acceptedEvent=1 limit 2 offset ${limitGetAllBusyHour}`);
    return {
        busyDates
    }
}

async function deleteOrder(busy_dates_details_code) {
    const response=await db.query(`DELETE FROM busy_dates_details WHERE busy_dates_details_code=${busy_dates_details_code}`);
    return {
        response
    }
}


module.exports = {
    makeAnOrder,
    getAcceptedOrders,
    getNotAcceptedOrders,
    waitingOrders,
    want2accept,
    getBusyDates,
    getEmail,
    deleteOrder,
    insertBusyTimeSinger,
    deleteAndInsert
}
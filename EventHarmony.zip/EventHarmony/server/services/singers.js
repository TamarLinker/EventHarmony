const db = require('./db');
const config = require('../config');
// const nodemailer = require('nodemailer');

// const transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//       user: 'projecttamarshani@gmail.com',
//       pass: 'gukuuhpqzeskhbre'
//   }
// });

// var mailOptions = {
//   from: 'projecttamarshani@gmail.com',
//   to: '',
//   subject: 'Website Partnership Notice',
//   text: 'Your receipt was received successfully!'
// };

// function sendEmail() {
//   transporter.sendMail(mailOptions, function (error, info) {
//       if (error) {
//           console.log(error);
//       } else {
//           console.log('Email sent: ' + info.response);
//       }
//   });
// }

async function getAcceptedSingers(limit) {
  const singers = await db.query(`SELECT * FROM singers WHERE accepted=1 AND NOT singer_code=1 limit 2 offset ${limit}`);
  return (singers)
}

async function getNotAcceptedSingers(limit) {

  const singers = await db.query(`SELECT * FROM singers WHERE accepted = 0 limit 2 offset ${limit}`);
  return (singers)
}

async function getMusicTypes() {
  const musicTypes = await db.query(`SELECT* FROM music_types`);
  console.log(musicTypes)
  return (musicTypes)
}

async function getSingersPorDate(user) {
  // const date1 = user.date;
  // const singers = await db.query(`SELECT singers.first_name,singers.last_name from singers JOIN busy_dates on singers.singer_code=busy_dates.singer_code WHERE busy_dates.busy_date = '${date1}' `);
  // return (singers)
}

async function deleteSinger(singersDetails) {
  const response = await db.query(`SELECT busy_dates_details.singer_code FROM busy_dates_details WHERE singer_code =${singersDetails.singer_code}`);
  if (response.length) {
    const changed = await db.query(`update singers set toBeDeleted=1 WHERE singer_code =${singersDetails.singer_code}`);
    return false;
  }
  else {
    await db.query(`DELETE FROM music_types_4_singers WHERE singer_code=${singersDetails.singer_code}`);
    await db.query(`DELETE FROM singers WHERE singer_code=${singersDetails.singer_code}`);   
    return true;
  }
}

async function want2accept(e_mail) {
   const changed = await db.query(`update singers set accepted=1 where e_mail="${e_mail}"`);
  // mailOptions.to=await db.query(`SELECT singers.e_mail FROM singers WHERE e_mail="${e_mail}"`);
  // sendEmail();
   return (changed);
}

async function availableSingers(dateDetails) {
  
  const availableSingers = await db.query(`SELECT * FROM singers WHERE singer_code in(select music_types_4_singers.singer_code from music_types_4_singers where singer_code in
    (select singers.singer_code from singers where singers.singer_code not in
    (select busy_dates_details.singer_code from busy_dates_details where busy_date="${dateDetails.busy_date}"
    and
    busy_dates_details.end_time>"${dateDetails.end_time}" and busy_dates_details.beginning_time<"${dateDetails.beginning_time}" ))
     and
    music_types_4_singers.music_types_code=${dateDetails.music_types_code} and toBeDeleted=0 )`);
  return (availableSingers);
}

module.exports = {
  getSingersPorDate,
  getAcceptedSingers,
  getNotAcceptedSingers,
  deleteSinger,
  want2accept,
  getMusicTypes,
  availableSingers
}
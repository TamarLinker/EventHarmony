-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: orchestra_4_event
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `busy_dates_details`
--

DROP TABLE IF EXISTS `busy_dates_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `busy_dates_details` (
  `busy_dates_details_code` int NOT NULL AUTO_INCREMENT,
  `singer_code` int NOT NULL,
  `busy_date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL,
  `costumer_code` int DEFAULT NULL,
  `is_event` tinyint(1) NOT NULL,
  `beginning_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL,
  `end_time` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci NOT NULL,
  `acceptedEvent` tinyint(1) NOT NULL DEFAULT '0',
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`busy_dates_details_code`),
  KEY `singer_code` (`singer_code`),
  KEY `costumer_code` (`costumer_code`),
  CONSTRAINT `busy_dates_details_ibfk_1` FOREIGN KEY (`singer_code`) REFERENCES `singers` (`singer_code`),
  CONSTRAINT `busy_dates_details_ibfk_2` FOREIGN KEY (`costumer_code`) REFERENCES `costumers` (`costumer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `busy_dates_details`
--

LOCK TABLES `busy_dates_details` WRITE;
/*!40000 ALTER TABLE `busy_dates_details` DISABLE KEYS */;
INSERT INTO `busy_dates_details` VALUES (1,2,'2023-09-23',NULL,1,'14:30:00','15:45:00',1,'שמש 32'),(2,23,'2022-10-18',2,1,'08:30:00','13:00:00',0,'מבוא די זהב 1'),(5,2,'2022-07-28',2,1,'20:46','19:46',1,'juhyt'),(6,2,'2022-07-28',2,1,'20:46','19:46',1,'mjhn'),(8,2,'2022-07-28',2,1,'20:46','19:46',1,'fcghjjbmnm,.njbhjhg'),(9,2,'2022-07-28',2,1,'20:46','19:46',1,'dfghjklכעינחימלחיליל'),(10,2,'2022-07-29',2,1,'19:56','19:55',1,'בצלאל'),(12,2,'2022-07-25',2,1,'04:23','03:23',0,'התבור'),(13,2,'2022-07-27',2,1,'10:28','05:23',0,'הזית'),(14,2,'2022-07-26',2,1,'23:29','11:29',1,'הארז 3'),(15,23,'2022-08-03',2,1,'15:31','11:31',0,'האורן 1'),(16,2,'2022-07-31',2,1,'23:31','13:25',0,'החרוב 34'),(17,2,'2023-10-23',3,1,'15:30:00','18:30:00',0,'שאולזון 51');
/*!40000 ALTER TABLE `busy_dates_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `costumers`
--

DROP TABLE IF EXISTS `costumers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `costumers` (
  `costumer_code` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `e_mail` varchar(45) DEFAULT NULL,
  `phone_number` varchar(11) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`costumer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `costumers`
--

LOCK TABLES `costumers` WRITE;
/*!40000 ALTER TABLE `costumers` DISABLE KEYS */;
INSERT INTO `costumers` VALUES (1,'תמר','לינקר','tamar@gmail.com','0658578676','999'),(2,'שני','הירשוביץ','shany9338@gmail.com','0548489338','888'),(3,'דבי','הירשוביץ','debbie9647@gmail.com','0583239647','777'),(6,'רות','רגובי',NULL,'546465335','666'),(7,'DSA','SA',NULL,'12','21');
/*!40000 ALTER TABLE `costumers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `music_types`
--

DROP TABLE IF EXISTS `music_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `music_types` (
  `music_types_code` int NOT NULL AUTO_INCREMENT,
  `musicTypeName` varchar(32) NOT NULL,
  PRIMARY KEY (`music_types_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `music_types`
--

LOCK TABLES `music_types` WRITE;
/*!40000 ALTER TABLE `music_types` DISABLE KEYS */;
INSERT INTO `music_types` VALUES (1,'הוק'),(2,'חסידי'),(3,'מזרחי'),(4,'שירי נשמה'),(5,'קלאסי'),(6,'פופ');
/*!40000 ALTER TABLE `music_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `music_types_4_singers`
--

DROP TABLE IF EXISTS `music_types_4_singers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `music_types_4_singers` (
  `music_types_4_singers_code` int NOT NULL AUTO_INCREMENT,
  `singer_code` int NOT NULL,
  `music_types_code` int NOT NULL,
  PRIMARY KEY (`music_types_4_singers_code`),
  KEY `singer_code` (`singer_code`),
  KEY `music_types_code` (`music_types_code`),
  CONSTRAINT `music_types_4_singers_ibfk_1` FOREIGN KEY (`singer_code`) REFERENCES `singers` (`singer_code`),
  CONSTRAINT `music_types_4_singers_ibfk_2` FOREIGN KEY (`music_types_code`) REFERENCES `music_types` (`music_types_code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `music_types_4_singers`
--

LOCK TABLES `music_types_4_singers` WRITE;
/*!40000 ALTER TABLE `music_types_4_singers` DISABLE KEYS */;
INSERT INTO `music_types_4_singers` VALUES (1,2,3),(2,2,1),(3,2,4),(6,23,2),(7,23,1);
/*!40000 ALTER TABLE `music_types_4_singers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `singers`
--

DROP TABLE IF EXISTS `singers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `singers` (
  `singer_code` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `phone_number` varchar(11) NOT NULL,
  `price` int NOT NULL,
  `accepted` tinyint(1) DEFAULT '0',
  `password` int DEFAULT NULL,
  `e_mail` varchar(45) NOT NULL,
  `toBeDeleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`singer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `singers`
--

LOCK TABLES `singers` WRITE;
/*!40000 ALTER TABLE `singers` DISABLE KEYS */;
INSERT INTO `singers` VALUES (1,'מנהל','מנהל','0583463356',100,1,185,'menahel@gmail.com',0),(2,'אברהם','פריד','0548489338',3333,1,123,'avraham@gmail.com',0),(23,'בני','פרידמן','0546467665',13987,1,1234,'beny1234@gmail.com',0),(29,'מרדכי','שפירא','54663534',45656900,1,13579,'mordechai@gmail.com',0);
/*!40000 ALTER TABLE `singers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-25 12:19:01
